---
name: clickup-task
description: Git commit'lar asosida ClickUp'da yangi task yaratadi. Foydalanuvchi "shuni clickupga kirit", "task qilib kir", "clickup task yarat", "shu ishni clickupga qo'sh" kabi so'zlar bilan chaqirganda ishlatiladi.
---

# ClickUp task yaratish

Foydalanuvchi bitta ish (feature/bugfix) ustida bir nechta commit qilgan bo'ladi, so'ngra shularni ClickUp'da bitta task qilib kiritishni so'raydi. Bu skill: commit'larni yig'adi, ulardan title/description yozadi, foydalanuvchidan ClickUp joyini so'raydi, tasdiqlatadi, task yaratadi va oxirida shu commit'larni ClickUp'ning task detallaridagi **"GitHub"** panelida ko'rinadigan qilib bog'laydi (commit xabari/PR title orqali, holatga qarab — 6-bosqich).

Muhim: commit ro'yxati task **description**'iga yozilmaydi — bu faqat matn bo'lib qoladi, real GitHub ulanishini hosil qilmaydi. Commit haqiqatan ham "GitHub" panelida ko'rinishi uchun commit xabari (yoki PR title)ning o'zida `CU-<taskID>` bo'lishi shart — buni 6-bosqich amalga oshiradi. Description faqat inson o'qiydigan qisqa xulosa uchun.

Hech qachon tasdiqsiz ClickUp'da task yaratma — bu tashqi/jamoaviy tizimga yozadigan amal.

## 1. Commit oralig'ini aniqlash

Agar foydalanuvchi allaqachon oraliqni aytgan bo'lsa (masalan "oxirgi 5 ta commit", "shu commit'dan boshlab", aniq hash/branch), shuni ishlat. Aks holda so'ra: qaysi commit'lar shu taskka tegishli?

Keyin commit ma'lumotlarini ol:
```
git log <range> --oneline
git log <range> --stat
```
Kerak bo'lsa (diff mazmuni tushunarsiz bo'lsa) `git show <hash>` bilan alohida commit'larni ham ko'rish mumkin, lekin katta diff'larni to'liq o'qishga urinma — `--stat` va commit xabarlari odatda yetarli.

`<range>` misollari: `HEAD~5..HEAD`, `<hash>..HEAD`, `main..HEAD`.

## 2. ClickUp joyini aniqlash

Foydalanuvchidan task qaysi List (va kerak bo'lsa Space/Folder) ga kiritilishini so'ra — agar u buni allaqachon aytmagan bo'lsa. Keyin `clickup_get_workspace_hierarchy` orqali workspace tuzilishini ol va foydalanuvchi aytgan nom bo'yicha mos List'ni top.

- Agar bitta aniq mos List topilsa — davom et.
- Agar bir nechta nomdosh/mos variant chiqsa yoki hech narsa topilmasa — taxmin qilma, foydalanuvchidan aniqlashtir.

List/Space nomini hech qachon oldindan qattiq yozib qo'ymagan bo'l — har safar yuqoridagi tartibda aniqlanadi.

## 3. Title va description yozish

Commit xabarlari va `--stat` xulosasi asosida:

- **Title**: qisqa, funksional o'zgarishni aks ettiruvchi (texnik jargon minimal, masalan "Filter.vue'da checkbox layout va filter parametrlari yaxshilandi").
- **Description**: nima o'zgargani haqida qisqa bullet-list (foydalanuvchi/vazifa nuqtai nazaridan, texnik detallarga cho'kmasdan). Commit hash/xabarlarini description'ga qo'shma — ular GitHub bog'lanishi orqali (6-bosqich) ClickUp'ning "GitHub" panelida avtomatik ko'rinadi, description'da takrorlashning hojati yo'q.

Tilni commit xabarlaridagi til bilan mosla (odatda o'zbek).

## 4. Tasdiqlash

Yaratishdan oldin foydalanuvchiga quyidagilarni ko'rsat va tasdiq so'ra:
- Tanlangan List (va Space/Folder).
- Draft title.
- Draft description.
- Assignee (standart: foydalanuvchining o'zi), Priority (standart: `urgent`), Start date (standart: bugungi sana).

Faqat foydalanuvchi tasdiqlagandan keyin 5-bosqichga o't. Agar u o'zgartirish so'rasa — draftni yangilab, qayta ko'rsat.

## 5. Task yaratish

`clickup_create_task` chaqir: aniqlangan List ID, tasdiqlangan title va description bilan, quyidagi standart maydonlar bilan birga:

- **Assignee**: doim foydalanuvchining o'zi (`clickup_resolve_assignees` bilan `"me"`ni user ID'ga aylantirib, `assignees` massiviga qo'y).
- **Priority**: doim `urgent`.
- **Start date**: task yaratilayotgan kunning sanasi (`YYYY-MM-DD`, bugungi sana).

Status va due date kabi qolgan maydonlarni faqat foydalanuvchi aniq aytgan bo'lsa qo'sh — aks holda bo'sh qoldir, taxmin qilma. Yuqoridagi uch standart maydon (assignee/priority/start date) 4-bosqichdagi tasdiqlash paytida draft bilan birga ko'rsatilishi kerak, shunda foydalanuvchi kerak bo'lsa o'zgartirishni so'rashi mumkin.

Javobdan task'ning **`task_id`**'sini yodda tut (masalan `86eyh50xk`) — 6-bosqichda `CU-<task_id>` shaklida kerak bo'ladi. Bu ClickUp'ning alohida "Custom ID" maydoni (odatda `null` bo'ladi) bilan chalkashtirilmasin — GitHub integratsiyasi doim `CU-<task_id>` (literal "CU-" prefiksi + qaytgan task ID) qolipini qidiradi.

## 6. Commit'larni ClickUp'ning GitHub paneliga bog'lash

ClickUp'ning GitHub integratsiyasi commit xabari, branch nomi yoki Pull Request title'ida Task ID (`CU-<taskID>`) bo'lsa, shu commit/branch/PR'ni avtomatik ravishda task'ning "GitHub" panelida ko'rsatadi (rasmda ko'rsatilgan joy). MCP orqali bu bog'lanishni to'g'ridan-to'g'ri yaratish imkoni yo'q — buni faqat commit xabari/branch/PR title orqali "tabiiy" hosil qilish mumkin. Shu sababli, task yaratilgandan keyin holatni tekshir va mos yo'lni tanla:

1. **Holatni tekshir**: `git status`, `git log @{u}..HEAD --oneline` (yoki mos branch uchun upstream solishtirish) orqali 1-bosqichdagi commit'lar hali remote'ga push qilinmaganmi, tekshir. Agar shu branch bo'yicha ochiq PR bor bo'lsa (`gh pr view` mavjud bo'lsa), uni ham tekshir.

2. **Agar commit'lar hali push qilinmagan bo'lsa** (faqat local): foydalanuvchidan aniq tasdiq so'rab, shu range'dagi har bir commit xabarini `CU-<taskID> - <asl xabar>` ko'rinishiga o'zgartirishni taklif qil:
   - Bitta commit bo'lsa: `git commit --amend -m "CU-<taskID> - <asl xabar>"`.
   - Bir nechta commit bo'lsa: interactive rebase (`git rebase -i <range-boshi>`) orqali har birining xabarini shu qolipga keltir.
   - Bu git tarixini qayta yozadi — hech qachon tasdiqsiz bajarma.

3. **Agar commit'lar push qilingan va shu branch bo'yicha ochiq (hali merge qilinmagan) PR bor bo'lsa**: tarixni buzmaslik uchun buning o'rniga PR title'iga `CU-<taskID> - ` prefiksini qo'shishni taklif qil (masalan `gh pr edit --title "CU-<taskID> - <asl title>"`). Bu ham ClickUp tomonidan avtomatik aniqlanadi.

4. **Agar commit'lar allaqachon merge qilingan bo'lsa**: commit xabarlarini yoki PR title'ni endi o'zgartirib bo'lmaydi (tarix allaqachon umumiy). Foydalanuvchiga buni tushuntir va commit hash'lari/PR havolasini taqdim et — ClickUp'ning GitHub panelidagi **"+ Add GitHub link"** tugmasi orqali qo'lda bog'lashi kerakligini ayt.

Har qanday variantda ham — amend, rebase yoki PR title o'zgartirish — FAQAT foydalanuvchi aniq tasdiqlagandan keyin bajariladi, chunki bular git tarixini yoki jamoaviy PR'ni o'zgartiradigan amallar.

## 7. Natija

Yaratilgan task havolasini va 6-bosqichda qanday bog'lanish amalga oshirilgani (yoki nima uchun qo'lda bog'lash kerakligi) haqida qisqa xulosani foydalanuvchiga qaytar.
